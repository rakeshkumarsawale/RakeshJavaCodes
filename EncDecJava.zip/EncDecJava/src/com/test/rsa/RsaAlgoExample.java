package com.test.rsa;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class RsaAlgoExample {
	
	private int keysize = 1024;
	
	private String transformation = "RSA/ECB/PKCS1Padding";					// (1024, 2048)
	//private String transformation = "RSA/ECB/OAEPWithSHA-1AndMGF1Padding";	// (1024, 2048)
	//private String transformation = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";	// (1024, 2048)
			
	private PrivateKey privateKey;
	private PublicKey publicKey;

	public RsaAlgoExample() throws NoSuchAlgorithmException {
		
		KeyPairGenerator genarator = KeyPairGenerator.getInstance("RSA");
		genarator.initialize(keysize);
		KeyPair pair = genarator.generateKeyPair();
		
		privateKey = pair.getPrivate();
		publicKey = pair.getPublic();
	}
	
	public String encrypt(String message) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		
		byte[] messageToBytes = message.getBytes();
		Cipher cipher = Cipher.getInstance(transformation);
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		byte[] encryptedbytes = cipher.doFinal(messageToBytes);
		return encode(encryptedbytes);
	}
	
	public String encode(byte[] data) {
		return Base64.getEncoder().encodeToString(data);
	}
	
	public String decrypt(String encryptedMessage) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
	
		byte[] encryptedBytes = decode(encryptedMessage);
		Cipher cipher = Cipher.getInstance(transformation);
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		byte[] decryptedMessage = cipher.doFinal(encryptedBytes);
		return new String(decryptedMessage, "UTF8");
	}
	
	private byte[] decode(String data) {
		return Base64.getDecoder().decode(data);				
	}
	
	public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
		
		RsaAlgoExample rsa = new RsaAlgoExample();
		
		String message = "Hellow RSA RSA/ECB/OAEPWithSHA-256AndMGF1Padding";
		System.out.println("message :"+message);
		
		String encryptedMessage = rsa.encrypt(message);
		System.out.println("encryptedMessage :"+encryptedMessage);

		String decryptedMessage = rsa.decrypt(encryptedMessage);		
		System.out.println("decryptedMessage :"+decryptedMessage);
		
		
	}

}
