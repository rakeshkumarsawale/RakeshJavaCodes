package com.test.rsa;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class RSAwithStaticKeys {
	
	private PrivateKey privateKey;
	private PublicKey publicKey;
	
	private static final String PUBLIC_KEY_STRING = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDbEgueXBTgwtqeVPvugOYLA4t2fd9Qiw8DNzkhUoG+XA2sRDbCkMFcRUVLRd3bA5NgIZhltgIOM8WBhpfvPWDwtjKjJ2FFrvyQiWA8O87HnoGREdXW+D/Al2yUwIsTGI5kjLLBRmwZKUWT3Kc5GnM+vv8WHMfachBeJ3PJv2QjKwIDAQAB";  
	private static final String PRIVATE_KEY_STRING = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBANsSC55cFODC2p5U++6A5gsDi3Z931CLDwM3OSFSgb5cDaxENsKQwVxFRUtF3dsDk2AhmGW2Ag4zxYGGl+89YPC2MqMnYUWu/JCJYDw7zseegZER1db4P8CXbJTAixMYjmSMssFGbBkpRZPcpzkacz6+/xYcx9pyEF4nc8m/ZCMrAgMBAAECgYA6CMZGLeuj/UqwDiBtdv06Jra/7amGq0gPWIZMcxCG7tj6bVm6YmGvAXTRc5FJz2Ev4sZ+D2DtBT8JyK+gQ7jVnl1n0mFicXSXj/0YgLcLPWj1yqQgeGf4TRL+5Ct6IRjdWcOCJY4EROryElGMnA3P63Adn0Hn3nS4AShocpELyQJBAOvCYN+MVu0Kv1lF2c87DHeNdsJdWtcMONwwgdA7WVGU49EA6Qmdj6lUUTc5rk87pozPQbIPo5JZu0OYQOEX5xkCQQDt4N+G/XZuYfRkG3fnRZMNlrXsUxyBkeO2M8AzWGni4zOP2gqmknty0OMjH0Z8Hgiy4g4QvHWJM54muoh+IvjjAkEAlhW7R/T2jZbO880U+Oj1adJj7R4zKz27oOk8asytctMfKLm0oQtuHnTv8wFEZ2po/7EdeHaeQhffsAtoGiP2WQJAI2LBPZ50wKTXqxCe/ItP/cR+mYIfinK+UftOyxSK49JyeCKyVOcTcBf8wdvEK3B4UMvp1bmDLn68Nvymk0T2iwJBAI7GoH6s8hpKkDVkOUgyJp30T+p0Pg3pwtQr6PZbUOLJaydYWjlYxFz9D3f8fM9iuOGHvQlBTzL5Z6gDgv0j1MU=";
		
	public void initFromKeys() throws NoSuchAlgorithmException, InvalidKeySpecException {
		
		X509EncodedKeySpec keySpecPublic = new X509EncodedKeySpec( decode(PUBLIC_KEY_STRING) );
		PKCS8EncodedKeySpec keySpecPrivate = new PKCS8EncodedKeySpec( decode(PRIVATE_KEY_STRING));
	
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		
		publicKey = keyFactory.generatePublic(keySpecPublic);
		privateKey = keyFactory.generatePrivate(keySpecPrivate);
	}
	
	
	public String encrypt(String message) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		
		byte[] messageToBytes = message.getBytes();
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		byte[] encryptedbytes = cipher.doFinal(messageToBytes);
		return encode(encryptedbytes);
	}
	
	public String encode(byte[] data) {
		return Base64.getEncoder().encodeToString(data);
	}
	
	public String decrypt(String encryptedMessage) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
	
		byte[] encryptedBytes = decode(encryptedMessage);
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		byte[] decryptedMessage = cipher.doFinal(encryptedBytes);
		return new String(decryptedMessage, "UTF8");
	}
	
	private byte[] decode(String data) {
		return Base64.getDecoder().decode(data);				
	}
	
	public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
		
		RSAwithStaticKeys rsa = new RSAwithStaticKeys();
		rsa.initFromKeys();
				
		String message = "Hellow RSA with STATIC keys";
		System.out.println("message :"+message);
		
		String encryptedMessage = rsa.encrypt(message);
		System.out.println("encryptedMessage :"+encryptedMessage);

		String decryptedMessage = rsa.decrypt(encryptedMessage);		
		System.out.println("decryptedMessage :"+decryptedMessage);
		
		
	}

}
