package com.test.rsa;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

public class RsaKeysGenerator {
	
	private PrivateKey privateKey;
	private PublicKey publicKey;

	public void init() throws NoSuchAlgorithmException {
		
		KeyPairGenerator genarator = KeyPairGenerator.getInstance("RSA");
		genarator.initialize(1024);
		KeyPair pair = genarator.generateKeyPair();
		
		privateKey = pair.getPrivate();
		publicKey = pair.getPublic();
	}
	
	public void printKeys() {
		System.out.println("Public Key:\n"+ encode(publicKey.getEncoded()));
		System.out.println("Private Key:\n"+ encode(privateKey.getEncoded()));
	}
		
	
	public String encode(byte[] data) {
		return Base64.getEncoder().encodeToString(data);
	}	
	
	public static void main(String[] args) throws NoSuchAlgorithmException {
		
		RsaKeysGenerator rsa = new RsaKeysGenerator();
		rsa.init();
		rsa.printKeys();		
	}

}
