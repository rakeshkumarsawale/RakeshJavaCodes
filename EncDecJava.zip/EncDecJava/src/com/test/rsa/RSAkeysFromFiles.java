package com.test.rsa;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class RSAkeysFromFiles {
	
	private String transformation = "RSA/ECB/PKCS1Padding";
	
	private PrivateKey privateKey;
	private PublicKey publicKey;

	public void initFromKeyFiles() throws NoSuchAlgorithmException, InvalidKeySpecException, IOException {

		String publicKeyFromFile = new String(Files.readAllBytes(Paths.get("src\\keys\\public_key.pem")));
		String publicKeyPEM = publicKeyFromFile.replace("-----BEGIN PUBLIC KEY-----", "")
				.replace("-----END PUBLIC KEY-----", "").replaceAll("\\s", "");// Remove all whitespace/line breaks
		System.out.println("PUBLIC KEY value\n" + publicKeyPEM);

		String privateKeyFromFile = new String(Files.readAllBytes(Paths.get("src\\keys\\private_key.pem")));
		String privateKeyPEM = privateKeyFromFile.replace("-----BEGIN PRIVATE KEY-----", "")
				.replace("-----END PRIVATE KEY-----", "").replaceAll("\\s", "");// Remove all whitespace/line breaks
		System.out.println("PRIVATE KEY value\n" + privateKeyPEM);

		X509EncodedKeySpec keySpecPublic = new X509EncodedKeySpec(decode(publicKeyPEM));
		PKCS8EncodedKeySpec keySpecPrivate = new PKCS8EncodedKeySpec(decode(privateKeyPEM));

		KeyFactory keyFactory = KeyFactory.getInstance("RSA");

		publicKey = keyFactory.generatePublic(keySpecPublic);
		privateKey = keyFactory.generatePrivate(keySpecPrivate);
	}

	public String encrypt(String message) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
			IllegalBlockSizeException, BadPaddingException {

		byte[] messageToBytes = message.getBytes();
		Cipher cipher = Cipher.getInstance(transformation);
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		byte[] encryptedbytes = cipher.doFinal(messageToBytes);
		return encode(encryptedbytes);
	}

	public String encode(byte[] data) {
		return Base64.getEncoder().encodeToString(data);
	}

	public String decrypt(String encryptedMessage) throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {

		byte[] encryptedBytes = decode(encryptedMessage);
		Cipher cipher = Cipher.getInstance(transformation);
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		byte[] decryptedMessage = cipher.doFinal(encryptedBytes);
		return new String(decryptedMessage, "UTF8");
	}

	private byte[] decode(String data) {
		return Base64.getDecoder().decode(data);
	}

	public static void main(String[] args) throws Exception {

		RSAkeysFromFiles rsa = new RSAkeysFromFiles();
		rsa.initFromKeyFiles();
		
		  String message = "Hellow RSA with PEM file keys.";
		  System.out.println("message :"+message);
		  
		  String encryptedMessage = rsa.encrypt(message);
		  System.out.println("encryptedMessage :"+encryptedMessage);
		  
		  String decryptedMessage = rsa.decrypt(encryptedMessage);
		  System.out.println("decryptedMessage :"+decryptedMessage);
		 

	}

}
