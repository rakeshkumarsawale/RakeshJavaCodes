package com.test.rsa;

import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class RsaKeysInFlight {

	public static void main(String[] args) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		// TODO Auto-generated method stub

		
		// Step 1: Create a KeyPairGenerator instance for RSA
		KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA"); 
		// Step 2: Initialize the generator with a key size (e.g., 2048 bits)
		keyGen.initialize(2048);  // 2048-bit RSA is secure for modern standards:contentReference[oaicite:10]{index=10}
		// Optionally, provide a SecureRandom for more entropy (Java uses a good default if not provided)
		// keyGen.initialize(2048, new SecureRandom());

		// Step 3: Generate the pair of keys
		KeyPair keyPair = keyGen.generateKeyPair();  

		// Step 4: Extract the private and public keys from the KeyPair
		PrivateKey privateKey = keyPair.getPrivate();
		PublicKey publicKey = keyPair.getPublic();
		
		//System.out.println("privateKey : "+privateKey.toString());
		//System.out.println("publicKey : "+publicKey.toString());

		// (Optional) Step 5: Serialize keys to bytes for storage or inspection
		byte[] publicKeyBytes = publicKey.getEncoded();   // X.509 format by default
		byte[] privateKeyBytes = privateKey.getEncoded(); // PKCS#8 format by default

		// (Optional) Convert keys to Base64 strings for readability or to save as text
		String pubKeyBase64 = Base64.getEncoder().encodeToString(publicKeyBytes);
		String privKeyBase64 = Base64.getEncoder().encodeToString(privateKeyBytes);

		System.out.println("Public Key (Base64): " + pubKeyBase64);
		System.out.println("Private Key (Base64): " + privKeyBase64);
		
		
		
		
		
		
		// Example data to encrypt
		String plaintext = "Hello, this is a secret message!";
		System.out.println("plaintext: "+plaintext);

		// Step 1: Create a Cipher instance for RSA encryption
		Cipher rsaCipher = Cipher.getInstance("RSA"); 
		// (The transformation "RSA" defaults to RSA/ECB/PKCS1Padding in the SunJCE provider)

		// Step 2: Initialize the Cipher in ENCRYPT_MODE with the public key
		rsaCipher.init(Cipher.ENCRYPT_MODE, publicKey);

		// Step 3: Encrypt the plaintext. Cipher works with byte arrays.
		byte[] plaintextBytes = plaintext.getBytes(java.nio.charset.StandardCharsets.UTF_8);
		byte[] ciphertextBytes = rsaCipher.doFinal(plaintextBytes);

		// (Optional) Encode the ciphertext to a readable form (e.g., Base64), especially if you need to display or transmit it as text
		String ciphertextBase64 = Base64.getEncoder().encodeToString(ciphertextBytes);
		System.out.println("Encrypted text (Base64): " + ciphertextBase64);
		
		
		// Step 1: Create another Cipher instance for RSA decryption 
		Cipher rsaDecryptCipher = Cipher.getInstance("RSA"); 
		// Step 2: Initialize the Cipher in DECRYPT_MODE with the private key
		rsaDecryptCipher.init(Cipher.DECRYPT_MODE, privateKey);

		// Step 3: Decode the ciphertext from Base64 (if it was encoded) to get raw bytes
		byte[] encryptedBytes = Base64.getDecoder().decode(ciphertextBase64);

		// Step 4: Decrypt the ciphertext bytes
		byte[] decryptedBytes = rsaDecryptCipher.doFinal(encryptedBytes);

		// Step 5: Convert decrypted bytes back into a string
		String decryptedText = new String(decryptedBytes, java.nio.charset.StandardCharsets.UTF_8);
		System.out.println("Decrypted text: " + decryptedText);
	}

}
