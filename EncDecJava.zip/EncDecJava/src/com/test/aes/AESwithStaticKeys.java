package com.test.aes;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AESwithStaticKeys {

	SecretKey key;
	private int T_LEN = 128;
	private byte[] IV;
	
	public void initFromStrings(String secretKey, String IV) {
		key = new SecretKeySpec(decode(secretKey), "AES");
		this.IV = decode(IV);
	}	
	
	public String encrypt(String message) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
		
		byte[] messageToBytes = message.getBytes();
		Cipher encryptionCipher = Cipher.getInstance("AES/GCM/NoPadding");
		GCMParameterSpec spec = new GCMParameterSpec(T_LEN, IV);
		encryptionCipher.init(Cipher.ENCRYPT_MODE, key, spec);		
		byte[] encryptedBytes = encryptionCipher.doFinal(messageToBytes);
		return encode(encryptedBytes);
	}
	
	public String decrypt(String encryptedMessage) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		byte[] encryptedMessageBytes = decode(encryptedMessage);
		Cipher decryptionCypher = Cipher.getInstance("AES/GCM/NoPadding");
		GCMParameterSpec spec = new GCMParameterSpec(T_LEN, IV);
		decryptionCypher.init(Cipher.DECRYPT_MODE, key, spec);
		byte[] decryptedBytes = decryptionCypher.doFinal(encryptedMessageBytes);
		return new String(decryptedBytes);
	}
	
	private String encode(byte[] data) {
		return Base64.getEncoder().encodeToString(data);
	}
	
	private byte[] decode(String data) {
		return Base64.getDecoder().decode(data);
	}
	
	public static void main(String[] args) {

		try {
		
			String message = "Hello AES STATIC KEYS";
			AESwithStaticKeys aes = new AESwithStaticKeys();
			aes.initFromStrings("axVZqpyyoEue0I75U3zt5w==", "lUSamlsKtbWtk3VB");
						
			System.out.println("message:"+message);
			
			String encryptedMsg = aes.encrypt(message);
			System.out.println("encryptedMsg:"+encryptedMsg);
					
			
			String decryptedMsg = aes.decrypt(encryptedMsg);
			System.out.println("decryptedMsg:"+decryptedMsg);
			
		}catch(Exception ex) {
			System.out.println(ex.getStackTrace());
		}
		
	}

}
