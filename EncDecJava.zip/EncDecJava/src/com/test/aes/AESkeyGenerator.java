package com.test.aes;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class AESkeyGenerator {

	SecretKey key;
	private int KEY_SIZE = 128;
	private byte[] IV;
	
	public void init() throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
		KeyGenerator generator = KeyGenerator.getInstance("AES");
		generator.init(KEY_SIZE);	
		key = generator.generateKey();
		
		Cipher encryptionCipher = Cipher.getInstance("AES/GCM/NoPadding");
		encryptionCipher.init(Cipher.ENCRYPT_MODE, key);
		IV = encryptionCipher.getIV();
	}
	
	public void printKeys() {
		System.out.println("Secret Key :"+encode(key.getEncoded()));
		System.out.println("IV :"+encode(IV));
	}
	
	private String encode(byte[] data) {
		return Base64.getEncoder().encodeToString(data);
	}
	
	public static void main(String[] args) {
		try {		
			AESkeyGenerator aes = new AESkeyGenerator();
			aes.init();
			aes.printKeys();			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		
	}

}
