package com.test.aes;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class AES {

	SecretKey key;
	private int KEY_SIZE = 128;
	private int T_LEN = 128;
	private Cipher encryptionCipher;
	
	private String transformation = "AES/GCM/NoPadding";
	
	
	public void init() throws NoSuchAlgorithmException {
		KeyGenerator generator = KeyGenerator.getInstance("AES");
		generator.init(KEY_SIZE);	
		key = generator.generateKey();
	}
	
	public String encrypt(String message) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		
		byte[] messageToBytes = message.getBytes();
		encryptionCipher = Cipher.getInstance(transformation);
		encryptionCipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] encryptedBytes = encryptionCipher.doFinal(messageToBytes);
		return encode(encryptedBytes);
	}
	
	public String decrypt(String encryptedMessage) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		byte[] encryptedMessageBytes = decode(encryptedMessage);
		Cipher decryptionCypher = Cipher.getInstance(transformation);
		GCMParameterSpec spec = new GCMParameterSpec(T_LEN, encryptionCipher.getIV());
		decryptionCypher.init(Cipher.DECRYPT_MODE, key, spec);
		byte[] decryptedBytes = decryptionCypher.doFinal(encryptedMessageBytes);
		return new String(decryptedBytes);
	}
	
	private String encode(byte[] data) {
		return Base64.getEncoder().encodeToString(data);
	}
	
	private byte[] decode(String data) {
		return Base64.getDecoder().decode(data);
	}
	
	public static void main(String[] args) {

		try {
		
			String message = "Hello AES world";
			AES aes = new AES();
			aes.init();
			
			System.out.println("message:"+message);
			
			String encryptedMsg = aes.encrypt(message);
			System.out.println("encryptedMsg:"+encryptedMsg);
			
			String decryptedMsg = aes.decrypt(encryptedMsg);
			System.out.println("decryptedMsg:"+decryptedMsg);
		
		}catch(Exception ex) {
			System.out.println(ex.getStackTrace());
		}
		
	}

}
